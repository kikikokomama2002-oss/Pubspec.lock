import 'package:flutter_test/flutter_test.dart';
import 'package:isar_community/isar.dart';
import '../lib/data/db/track.dart';

void main() {
  test('searchWords contains Unicode-aware words from title, artist and album', () {
    final track = Track()
      ..title = 'The Blue Café'
      ..artist = 'José & The Kids'
      ..album = 'Live, Vol. 2'
      ..searchWords = [
        ...Isar.splitWords('The Blue Café'),
        ...Isar.splitWords('José & The Kids'),
        ...Isar.splitWords('Live, Vol. 2'),
      ];

    expect(track.searchWords, contains('The'));
    expect(track.searchWords, contains('Blue'));
    expect(track.searchWords, contains('Café'));
    expect(track.searchWords, contains('José'));
    expect(track.searchWords, contains('Kids'));
    expect(track.searchWords, contains('Live'));
    expect(track.searchWords, contains('Vol'));
  });

  test('punctuation-only input has no searchable tokens', () {
    expect(Isar.splitWords('!!! ??? ---').isEmpty, isTrue);
  });

  test('searchWords does not depend on arbitrary substring fragments', () {
    final track = Track()
      ..title = 'Sunshine'
      ..artist = 'Example'
      ..album = 'Album'
      ..searchWords = [
        ...Isar.splitWords('Sunshine'),
        ...Isar.splitWords('Example'),
        ...Isar.splitWords('Album'),
      ];

    expect(track.searchWords, contains('Sunshine'));
    expect(track.searchWords, isNot(contains('unsh')));
  });
}
