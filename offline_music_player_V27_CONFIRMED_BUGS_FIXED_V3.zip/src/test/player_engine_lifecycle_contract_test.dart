import 'dart:io';

import 'package:flutter_test/flutter_test.dart';

void main() {
  test('foreground reattachment destroys the old headless queue runtime', () {
    final source = File('android/app/src/main/kotlin/com/example/musicplayer/playback/PlayerHolder.kt').readAsStringSync();
    final start = source.indexOf('fun ensureQueueController(');
    final end = source.indexOf('fun setQueueContext(', start);
    final body = source.substring(start, end);
    expect(body, contains('headlessQueueRuntime?.destroy()'));
    expect(body, contains('headlessQueueRuntime = null'));
  });

  test('headless PlayerChannel disposal does not clear the shared library generation', () {
    final channel = File('android/app/src/main/kotlin/com/example/musicplayer/channels/PlayerChannel.kt').readAsStringSync();
    final runtime = File('android/app/src/main/kotlin/com/example/musicplayer/playback/HeadlessFlutterQueueRuntime.kt').readAsStringSync();
    expect(channel, contains('clearLibraryGenerationOnDispose: Boolean = true'));
    expect(channel, contains('if (clearLibraryGenerationOnDispose)'));
    expect(runtime, contains('clearLibraryGenerationOnDispose = false'));
  });
}
